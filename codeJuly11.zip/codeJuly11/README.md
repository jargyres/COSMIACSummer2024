The code to generate the pattern is from generate_pattern.py

If you want to run this, you will need to make a virtual environment in sdr_scripts folder with all the dependencies
